This IPython notebook newprogram.ipynb does not require any additional
programs.
